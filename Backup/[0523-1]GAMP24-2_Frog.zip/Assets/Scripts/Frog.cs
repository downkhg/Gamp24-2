using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Frog : MonoBehaviour
{
    public float speed;
    public float jumpPower;

    public float curTime = -1;
    public float time;

    public bool isJump;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(isJump)
            transform.position += Vector3.left * speed * Time.deltaTime;

        if (curTime < 0) //-1 < 0 -> T
        {
            Debug.Log($"Start");
            curTime = 0; // 0
        }


        if (curTime >= 0)
        {
            curTime += Time.deltaTime;
        }


        if (curTime >= time)
        {
            Debug.Log($"Jump!");
            GetComponent<Rigidbody2D>().AddForce(Vector3.up * jumpPower);
            isJump = true;
            curTime = -1;
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        isJump = false;
    }
}
